package com.bank.dao;

public interface AccountDao {
	//public Account getUser
}
