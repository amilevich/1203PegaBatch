package com.bank.main;

public class Joint {
	int jointID;
	int accountOpen;

}
